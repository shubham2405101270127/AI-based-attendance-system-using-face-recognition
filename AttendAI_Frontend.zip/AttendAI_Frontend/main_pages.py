"""
AttendAI Frontend — Main Entry File
====================================
File: main_pages.py
Role: This is the MAIN file for the Frontend layer.
      It is a FastAPI router that serves every HTML page in the templates/ folder.
      Mount this in the root main.py with:
          from frontend import main_pages
          app.include_router(main_pages.router)

Pages served:
  GET /           → templates/index.html      (Home / landing page)
  GET /session    → templates/session.html    (Live camera attendance session)
  GET /register   → templates/register.html   (Student registration + face capture)
  GET /faculty    → templates/faculty.html    (Faculty directory + profiles)
  GET /dashboard  → templates/dashboard.html  (Teacher analytics dashboard)
"""

from fastapi import APIRouter
from fastapi.responses import FileResponse

router = APIRouter()


@router.get("/", summary="Home Page")
async def home():
    """Landing page — shows live stats and feature overview."""
    return FileResponse("templates/index.html")


@router.get("/session", summary="Live Attendance Session")
async def session():
    """
    Live session page.
    Teacher selects Department → Subject → Faculty,
    then starts the MJPEG camera stream.
    Students are marked present after 5-frame confidence threshold.
    """
    return FileResponse("templates/session.html")


@router.get("/register", summary="Student Registration")
async def register():
    """
    Two-tab page:
      Tab 1 — Register New: Name, City, Dept dropdown, Phone, Guardian radio
      Tab 2 — Manage Students: cards with profile + delete
    """
    return FileResponse("templates/register.html")


@router.get("/faculty", summary="Faculty Directory")
async def faculty():
    """
    Faculty directory page.
    Shows cards for all 25 pre-seeded faculty members.
    Click any card to see their full session history in a popup modal.
    """
    return FileResponse("templates/faculty.html")


@router.get("/dashboard", summary="Teacher Dashboard")
async def dashboard():
    """
    Analytics dashboard.
    Shows KPI cards, 14-day bar chart, low-attendance list,
    paginated session table with bulk-delete, CSV export and View popup.
    """
    return FileResponse("templates/dashboard.html")
