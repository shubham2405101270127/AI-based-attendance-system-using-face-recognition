# AttendAI — Frontend Layer

## What is this?
This folder contains everything the teacher sees and interacts with in the browser.
It is pure HTML + CSS + JavaScript — no React, no framework, no build step needed.

## Folder Structure
```
AttendAI_Frontend/
│
├── main_pages.py          ← MAIN FILE — FastAPI router that serves all HTML pages
│
├── templates/             ← One HTML file per page
│   ├── index.html         ← Home / landing page (stats + feature overview)
│   ├── session.html       ← Live attendance session (camera + attendance list)
│   ├── register.html      ← Student registration + face capture (2-tab)
│   ├── faculty.html       ← Faculty directory with profile popups
│   └── dashboard.html     ← Teacher analytics, session history, CSV export
│
└── static/
    ├── css/
    │   └── style.css      ← Global base styles shared by all pages
    └── js/
        └── main.js        ← Shared JavaScript utilities (toast, fetch, webcam)
```

## Pages & What They Do

| URL         | File                  | Purpose                                              |
|-------------|-----------------------|------------------------------------------------------|
| /           | index.html            | Home page — live stats banner + feature cards        |
| /session    | session.html          | Start a session, pick dept/subject/faculty, camera   |
| /register   | register.html         | Register students + capture 4 face photos            |
| /faculty    | faculty.html          | Browse all faculty, click for session history        |
| /dashboard  | dashboard.html        | KPIs, trend chart, session list, bulk delete, CSV    |

## Technologies Used
- HTML5 / CSS3 — page structure and layout
- Vanilla JavaScript (ES6) — all interactions, API calls, live updates
- Chart.js (loaded from CDN) — bar chart on dashboard
- MJPEG stream — live camera feed shown as an <img> tag
- Fetch API — all data loaded from the FastAPI backend
- No npm, no build tools, no React — runs directly in any browser

## How to Wire Into the Backend
In your root `main.py`, make sure this is included:

```python
from app.api import pages          # this is main_pages.py contents
app.include_router(pages.router)   # serves all HTML pages
app.mount("/static", StaticFiles(directory="static"), name="static")
```

## Key Design Decisions
- Each HTML file is self-contained with its own <style> block for page-specific styles
- style.css holds only shared base styles (nav, buttons, modal, toast, footer)
- main.js provides reusable helpers: showToast(), apiFetch(), startWebcam(), captureFrame()
- All API calls go to /api/* endpoints served by the backend layer
