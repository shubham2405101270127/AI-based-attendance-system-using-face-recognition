/**
 * AttendAI — Shared JavaScript Utilities
 * These helpers are available on every page via <script src="/static/js/main.js">
 */

// ── Toast notification ────────────────────────────────────────────────────────
function showToast(msg, isError = false) {
  let t = document.getElementById('toast');
  if (!t) {
    t = document.createElement('div');
    t.id = 'toast';
    t.className = 'toast';
    document.body.appendChild(t);
  }
  t.textContent = msg;
  t.style.background = isError ? '#dc2626' : '#059669';
  t.classList.add('show');
  setTimeout(() => t.classList.remove('show'), 3500);
}

// ── Fetch wrapper with error handling ─────────────────────────────────────────
async function apiFetch(url, options = {}) {
  try {
    const res = await fetch(url, {
      headers: { 'Content-Type': 'application/json' },
      ...options,
    });
    const data = await res.json();
    if (!res.ok) throw new Error(data.detail || `HTTP ${res.status}`);
    return data;
  } catch (err) {
    showToast(err.message, true);
    throw err;
  }
}

// ── Confidence colour helper ──────────────────────────────────────────────────
function confColor(pct) {
  if (pct >= 75) return 'var(--green, #059669)';
  if (pct >= 55) return 'var(--amber, #d97706)';
  return 'var(--red, #dc2626)';
}

// ── Format datetime ───────────────────────────────────────────────────────────
function fmtDate(iso) {
  if (!iso) return '—';
  return new Date(iso).toLocaleDateString();
}
function fmtTime(iso) {
  if (!iso) return '—';
  return new Date(iso).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
}
function fmtDateTime(iso) {
  if (!iso) return '—';
  return new Date(iso).toLocaleString();
}

// ── Close modals on Escape ────────────────────────────────────────────────────
document.addEventListener('keydown', e => {
  if (e.key === 'Escape') {
    document.querySelectorAll('.modal-overlay').forEach(m => {
      m.style.display = 'none';
    });
  }
});

// ── Webcam helper ─────────────────────────────────────────────────────────────
async function startWebcam(videoEl, opts = {}) {
  const constraints = {
    video: {
      width:     { ideal: opts.width     || 480 },
      height:    { ideal: opts.height    || 360 },
      frameRate: { ideal: opts.frameRate || 15  },
    }
  };
  const stream = await navigator.mediaDevices.getUserMedia(constraints);
  videoEl.srcObject = stream;
  return stream;
}

function captureFrame(videoEl, canvasEl, quality = 0.8) {
  canvasEl.width  = videoEl.videoWidth;
  canvasEl.height = videoEl.videoHeight;
  canvasEl.getContext('2d').drawImage(videoEl, 0, 0);
  return canvasEl.toDataURL('image/jpeg', quality).split(',')[1];
}
