# AttendAI — Backend Layer

## What is this?
This folder contains the entire Python backend — the FastAPI web server, all API
endpoints, the AI face recognition engine, the anti-spoofing logic, and the
database service layer.

## Folder Structure
```
AttendAI_Backend/
│
├── main.py                          ← MAIN FILE — start the server from here
├── requirements.txt                 ← pip install list
├── launch.bat                       ← Windows double-click launcher
│
├── app/
│   ├── api/
│   │   ├── students.py              ← /api/students/* (register, capture, list, delete)
│   │   ├── attendance.py            ← /api/attendance/* (sessions, reports, CSV export)
│   │   ├── dashboard.py             ← /api/dashboard/* (stats, faculty analytics)
│   │   ├── video.py                 ← /api/video/* (MJPEG stream, photo upload)
│   │   └── pages.py                 ← serves HTML pages from templates/
│   │
│   ├── core/
│   │   └── face_engine.py           ← AI core: detection, embedding, anti-spoof, liveness
│   │
│   ├── services/
│   │   └── recognition_service.py   ← bridges face engine with the database
│   │
│   └── models/
│       └── database.py              ← SQLite schema + init + safe migrations
│
└── scripts/
    └── seed_master.py               ← seeds 5 depts, 25 subjects, 25 faculty
```

## How to Run

### Step 1 — Create virtual environment
```
python -m venv venv
venv\Scripts\activate        (Windows)
source venv/bin/activate     (Mac/Linux)
```

### Step 2 — Install packages
```
pip install -r requirements.txt
```

### Step 3 — Seed master data (run once)
```
python scripts/seed_master.py
```

### Step 4 — Start the server
```
uvicorn main:app --host 0.0.0.0 --port 8000 --reload
```
Or just double-click `launch.bat` on Windows.

### Step 5 — Open browser
```
http://127.0.0.1:8000
```

## API Files — What Each One Does

| File               | Prefix            | Key endpoints                                          |
|--------------------|-------------------|--------------------------------------------------------|
| students.py        | /api/students     | POST /register, POST /capture-face, GET /, DELETE /:id |
|                    |                   | GET /meta/departments, /meta/subjects/:code, /meta/faculty/:code |
| attendance.py      | /api/attendance   | POST /session/start, POST /session/:id/end             |
|                    |                   | GET /sessions (paginated), DELETE /session/:id         |
|                    |                   | DELETE /sessions/bulk, DELETE /sessions/clear-all      |
|                    |                   | GET /report/export/:id (CSV download)                  |
| dashboard.py       | /api/dashboard    | GET /stats, GET /faculty/all, GET /faculty/:id/sessions|
| video.py           | /api/video        | POST /start-session, POST /stop-session                |
|                    |                   | GET /stream (MJPEG), POST /process-photo               |
| pages.py           | /                 | GET / /session /register /faculty /dashboard           |

## Core AI Logic (face_engine.py)

| Feature               | How it works                                                  |
|-----------------------|---------------------------------------------------------------|
| Face detection        | OpenCV HOG detector, resized to 50% for speed                |
| Embedding extraction  | DeepFace Facenet → 128-dimensional float vector              |
| Matching              | Cosine similarity, threshold 0.60                            |
| Anti-spoof Layer 1    | LBP texture variance < 80 → rejected as photo/screen        |
| Anti-spoof Layer 2    | Eye-blink via dlib 68-pt landmarks (if model file present)   |
| Confirmation gate     | Must appear in 5+ frames within 8 seconds                    |

## Tuning Constants (top of face_engine.py)
```python
RECOGNITION_THRESHOLD   = 0.60   # lower = stricter
CONFIRM_FRAMES_REQUIRED = 5       # frames needed before marking present
CONFIRM_WINDOW_SECONDS  = 8       # rolling time window
LBP_VARIANCE_THRESHOLD  = 80.0   # below this = likely spoofed
```
