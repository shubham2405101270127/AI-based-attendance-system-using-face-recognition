@echo off
title AttendAI — Backend Server
echo.
echo  Starting AttendAI Backend...
echo  Please wait about 15 seconds for DeepFace to load.
echo.

cd /d %~dp0
call venv\Scripts\activate

start "" http://127.0.0.1:8000
timeout /t 15 /nobreak >nul

uvicorn main:app --host 0.0.0.0 --port 8000 --reload
