"""
AttendAI Backend — Main Entry File
====================================
File:    main.py
Role:    MAIN FILE for the entire backend.
         Run this file to start the server:
             uvicorn main:app --host 0.0.0.0 --port 8000 --reload

What it does:
  1. Creates the FastAPI application instance
  2. Registers all API routers (students, attendance, dashboard, video, pages)
  3. Mounts the /static folder for CSS/JS files
  4. Initialises the SQLite database on startup (creates all tables + runs migrations)
  5. Configures CORS so the browser can talk to the API

Access the app at:
  http://localhost:8000          → Home page
  http://localhost:8000/docs     → Interactive API documentation (auto-generated)
  http://localhost:8000/session  → Live session
  http://localhost:8000/dashboard → Teacher dashboard
"""

import uvicorn
from fastapi import FastAPI
from fastapi.staticfiles import StaticFiles
from fastapi.middleware.cors import CORSMiddleware
from contextlib import asynccontextmanager

from app.api import students, attendance, dashboard, video, pages
from app.models.database import init_db


@asynccontextmanager
async def lifespan(app: FastAPI):
    """
    Startup: initialise the SQLite database.
    Creates all tables and runs safe column migrations if needed.
    """
    await init_db()
    yield
    # Shutdown: nothing to clean up (SQLite closes automatically)


app = FastAPI(
    title="AttendAI — Face Recognition Attendance System",
    description=(
        "AI-powered classroom attendance using real-time face recognition, "
        "anti-spoofing (LBP texture + eye-blink), and a 5-frame confidence threshold. "
        "Supports departments, subjects, faculty, student profiles, and CSV exports."
    ),
    version="2.0.0",
    lifespan=lifespan,
)

# ── CORS ──────────────────────────────────────────────────────────────────────
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],       # restrict to specific domains in production
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# ── Static files (CSS, JS) ────────────────────────────────────────────────────
app.mount("/static", StaticFiles(directory="static"), name="static")

# ── API routers ───────────────────────────────────────────────────────────────
app.include_router(students.router,   prefix="/api/students",   tags=["Students"])
app.include_router(attendance.router, prefix="/api/attendance", tags=["Attendance"])
app.include_router(dashboard.router,  prefix="/api/dashboard",  tags=["Dashboard"])
app.include_router(video.router,      prefix="/api/video",      tags=["Video"])
app.include_router(pages.router,      tags=["Pages"])           # serves HTML


if __name__ == "__main__":
    uvicorn.run(
        "main:app",
        host="0.0.0.0",
        port=8000,
        reload=True,    # remove --reload in production
    )
