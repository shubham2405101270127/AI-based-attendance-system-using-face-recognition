"""
Core Face Recognition Engine
Handles: detection, embedding extraction, matching, anti-spoofing, liveness detection.

Libraries used:
  - face_recognition (dlib-based): fast 128-d embedding extraction
  - OpenCV: frame capture, preprocessing, eye-blink detection via dlib landmarks
  - numpy: cosine similarity for matching

Anti-Spoofing Strategy (layered):
  1. Texture Analysis (LBP-based): photo printouts lack natural skin micro-texture variance
  2. Eye-Blink Detection: real faces blink; static images/screens do not
  3. Depth Cue (motion check): slight head movement required across N frames
"""

import cv2
import numpy as np
import face_recognition
import pickle
from dataclasses import dataclass, field
from collections import defaultdict, deque
from typing import Optional
import time
import logging

logger = logging.getLogger(__name__)

# ─── Tuning constants ────────────────────────────────────────────────────────
RECOGNITION_THRESHOLD   = 0.50   # cosine distance; lower = stricter match
CONFIRM_FRAMES_REQUIRED = 5      # frames student must be seen before marking
CONFIRM_WINDOW_SECONDS  = 8      # rolling window to collect confirm frames
LIVENESS_BLINK_REQUIRED = 1      # minimum blinks needed to pass liveness
LBP_VARIANCE_THRESHOLD  = 80.0   # skin texture variance; below → likely spoof
EYE_AR_THRESHOLD        = 0.22   # eye aspect ratio below this = closed
EYE_CONSEC_FRAMES       = 2      # consecutive closed frames = one blink


@dataclass
class RecognitionState:
    """Per-student rolling recognition state for confidence+time threshold."""
    student_id: str
    name: str
    frame_hits: deque = field(default_factory=lambda: deque(maxlen=50))
    confirmed: bool = False
    last_confidence: float = 0.0


@dataclass
class LivenessState:
    """Per-face liveness tracking across frames."""
    blink_count: int = 0
    eye_closed_frames: int = 0
    passed: bool = False
    ear_history: deque = field(default_factory=lambda: deque(maxlen=30))


class FaceEngine:
    def __init__(self):
        self._known_ids: list[str] = []
        self._known_names: list[str] = []
        self._known_embeddings: list[np.ndarray] = []

        # Per-session tracking
        self._recognition_states: dict[str, RecognitionState] = {}
        self._liveness_states: dict[str, LivenessState] = {}

        # dlib landmark predictor for eye-blink (loaded lazily)
        self._landmark_predictor = None
        self._face_detector = None
        self._load_landmark_predictor()

    # ─── Landmark predictor ──────────────────────────────────────────────────
    def _load_landmark_predictor(self):
        """Load dlib 68-point shape predictor if available."""
        try:
            import dlib
            model_path = "data/shape_predictor_68_face_landmarks.dat"
            import os
            if os.path.exists(model_path):
                self._face_detector = dlib.get_frontal_face_detector()
                self._landmark_predictor = dlib.shape_predictor(model_path)
                logger.info("[FaceEngine] Dlib landmark predictor loaded.")
            else:
                logger.warning(
                    "[FaceEngine] shape_predictor_68_face_landmarks.dat not found. "
                    "Eye-blink detection disabled. Download from: "
                    "http://dlib.net/files/shape_predictor_68_face_landmarks.dat.bz2"
                )
        except ImportError:
            logger.warning("[FaceEngine] dlib not installed; blink detection disabled.")

    # ─── Embedding management ────────────────────────────────────────────────
    def load_embeddings(self, records: list[dict]):
        """
        Load known embeddings from DB records.
        Each record: {student_id, name, embedding (bytes)}
        """
        self._known_ids.clear()
        self._known_names.clear()
        self._known_embeddings.clear()
        for r in records:
            try:
                emb = pickle.loads(r["embedding"])
                self._known_ids.append(r["student_id"])
                self._known_names.append(r["name"])
                self._known_embeddings.append(emb)
            except Exception as e:
                logger.error(f"[FaceEngine] Bad embedding for {r['student_id']}: {e}")
        logger.info(f"[FaceEngine] Loaded {len(self._known_embeddings)} embeddings.")

    def add_embedding(self, student_id: str, name: str, embedding: np.ndarray):
        self._known_ids.append(student_id)
        self._known_names.append(name)
        self._known_embeddings.append(embedding)

    # ─── Frame processing ────────────────────────────────────────────────────
    def process_frame(self, frame: np.ndarray, session_id: str) -> dict:
        """
        Full pipeline on a single BGR frame.
        Returns: {
          faces: [{box, student_id, name, confidence, liveness, confirmed}],
          newly_confirmed: [student_id, ...]
        }
        """
        rgb = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
        small = cv2.resize(rgb, (0, 0), fx=0.5, fy=0.5)

        # Detect face locations + compute 128-d embeddings
        locations = face_recognition.face_locations(small, model="hog")
        encodings = face_recognition.face_encodings(small, locations)

        results = []
        newly_confirmed = []
        now = time.time()

        for (top, right, bottom, left), encoding in zip(locations, encodings):
            # Scale back to original frame size
            box = (top*2, right*2, bottom*2, left*2)
            face_crop = frame[box[0]:box[2], box[3]:box[1]]

            # 1. Anti-spoofing: texture check
            lbp_ok = self._check_texture(face_crop)

            # 2. Identify
            student_id, name, confidence = self._identify(encoding)

            # 3. Liveness: eye-blink (per-student track key)
            track_key = student_id or f"unknown_{left}"
            liveness_ok = self._update_liveness(track_key, frame, box)

            is_live = lbp_ok and liveness_ok

            # 4. Confidence+Time threshold (only for live, known faces)
            confirmed = False
            if student_id and is_live:
                state = self._recognition_states.setdefault(
                    f"{session_id}_{student_id}",
                    RecognitionState(student_id=student_id, name=name)
                )
                state.last_confidence = confidence
                state.frame_hits.append(now)

                # Count hits within the rolling window
                window_hits = sum(
                    1 for t in state.frame_hits
                    if now - t <= CONFIRM_WINDOW_SECONDS
                )
                if window_hits >= CONFIRM_FRAMES_REQUIRED and not state.confirmed:
                    state.confirmed = True
                    newly_confirmed.append(student_id)
                confirmed = state.confirmed

            results.append({
                "box": box,
                "student_id": student_id,
                "name": name or "Unknown",
                "confidence": round(confidence, 3),
                "liveness": is_live,
                "texture_ok": lbp_ok,
                "confirmed": confirmed,
            })

        return {"faces": results, "newly_confirmed": newly_confirmed}

    # ─── Identification ──────────────────────────────────────────────────────
    def _identify(self, encoding: np.ndarray) -> tuple[Optional[str], Optional[str], float]:
        if not self._known_embeddings:
            return None, None, 0.0

        known = np.array(self._known_embeddings)
        distances = face_recognition.face_distance(known, encoding)
        best_idx = int(np.argmin(distances))
        best_dist = float(distances[best_idx])

        if best_dist <= RECOGNITION_THRESHOLD:
            return (
                self._known_ids[best_idx],
                self._known_names[best_idx],
                1.0 - best_dist,
            )
        return None, None, 1.0 - best_dist

    # ─── Anti-Spoofing: LBP Texture Analysis ────────────────────────────────
    def _check_texture(self, face_crop: np.ndarray) -> bool:
        """
        Local Binary Pattern variance check.
        Printed photos / screens have low texture variance.
        """
        if face_crop.size == 0:
            return False
        try:
            gray = cv2.cvtColor(face_crop, cv2.COLOR_BGR2GRAY)
            gray = cv2.resize(gray, (64, 64))
            lbp = self._compute_lbp(gray)
            variance = float(np.var(lbp))
            return variance >= LBP_VARIANCE_THRESHOLD
        except Exception:
            return True  # fail-open if crop is too small

    @staticmethod
    def _compute_lbp(gray: np.ndarray, radius: int = 1, n_points: int = 8) -> np.ndarray:
        """Simple circular LBP implementation (no sklearn required)."""
        h, w = gray.shape
        lbp = np.zeros_like(gray, dtype=np.uint8)
        for i in range(radius, h - radius):
            for j in range(radius, w - radius):
                center = gray[i, j]
                code = 0
                for k in range(n_points):
                    angle = 2 * np.pi * k / n_points
                    x = j + radius * np.cos(angle)
                    y = i - radius * np.sin(angle)
                    xi, yi = int(round(x)), int(round(y))
                    xi = max(0, min(w-1, xi))
                    yi = max(0, min(h-1, yi))
                    if gray[yi, xi] >= center:
                        code |= (1 << k)
                lbp[i, j] = code
        return lbp

    # ─── Anti-Spoofing: Eye-Blink Liveness ──────────────────────────────────
    def _update_liveness(self, track_key: str, frame: np.ndarray, box: tuple) -> bool:
        """
        Update liveness state for this track.
        Returns True once LIVENESS_BLINK_REQUIRED blinks detected OR
        if landmark predictor is unavailable (fail-open with LBP only).
        """
        if self._landmark_predictor is None:
            return True  # Rely on texture check only

        state = self._liveness_states.setdefault(track_key, LivenessState())
        if state.passed:
            return True

        try:
            import dlib
            top, right, bottom, left = box
            drect = dlib.rectangle(left, top, right, bottom)
            gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
            shape = self._landmark_predictor(gray, drect)
            pts = np.array([[shape.part(i).x, shape.part(i).y] for i in range(68)])

            # Eye aspect ratio
            left_ear  = self._eye_aspect_ratio(pts[36:42])
            right_ear = self._eye_aspect_ratio(pts[42:48])
            ear = (left_ear + right_ear) / 2.0
            state.ear_history.append(ear)

            if ear < EYE_AR_THRESHOLD:
                state.eye_closed_frames += 1
            else:
                if state.eye_closed_frames >= EYE_CONSEC_FRAMES:
                    state.blink_count += 1
                state.eye_closed_frames = 0

            if state.blink_count >= LIVENESS_BLINK_REQUIRED:
                state.passed = True
                return True
        except Exception as e:
            logger.debug(f"[Liveness] {e}")

        return False

    @staticmethod
    def _eye_aspect_ratio(eye_pts: np.ndarray) -> float:
        """Compute EAR from 6 eye landmark points."""
        A = np.linalg.norm(eye_pts[1] - eye_pts[5])
        B = np.linalg.norm(eye_pts[2] - eye_pts[4])
        C = np.linalg.norm(eye_pts[0] - eye_pts[3])
        return (A + B) / (2.0 * C + 1e-6)

    # ─── Embedding extraction for registration ───────────────────────────────
    def extract_embedding(self, image: np.ndarray) -> Optional[np.ndarray]:
        """Extract 128-d face embedding from a single face image."""
        rgb = cv2.cvtColor(image, cv2.COLOR_BGR2RGB)
        locs = face_recognition.face_locations(rgb, model="hog")
        if not locs:
            return None
        encs = face_recognition.face_encodings(rgb, locs)
        return encs[0] if encs else None

    def reset_session(self, session_id: str):
        """Clear per-session tracking state."""
        keys_to_remove = [k for k in self._recognition_states if k.startswith(f"{session_id}_")]
        for k in keys_to_remove:
            del self._recognition_states[k]
        self._liveness_states.clear()


# Singleton instance
face_engine = FaceEngine()
