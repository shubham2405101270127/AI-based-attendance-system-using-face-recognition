"""Dashboard & Faculty analytics API — v3"""
from fastapi import APIRouter
from app.models.database import DB_PATH
import aiosqlite

router = APIRouter()


@router.get("/stats")
async def dashboard_stats():
    async with aiosqlite.connect(DB_PATH) as db:
        db.row_factory = aiosqlite.Row

        async with db.execute(
            "SELECT COUNT(*) AS c FROM students WHERE is_active=1"
        ) as cur:
            total_students = (await cur.fetchone())["c"]

        async with db.execute(
            "SELECT COUNT(*) AS c FROM attendance_sessions WHERE date(started_at)=date('now') AND is_deleted=0"
        ) as cur:
            sessions_today = (await cur.fetchone())["c"]

        async with db.execute("""
            SELECT COUNT(DISTINCT al.student_id) AS c
            FROM attendance_logs al
            JOIN attendance_sessions s ON s.session_id = al.session_id
            WHERE date(al.marked_at) = date('now') AND s.is_deleted = 0
        """) as cur:
            present_today = (await cur.fetchone())["c"]

        async with db.execute("""
            SELECT s.student_id, s.name, COUNT(al.id) AS attended
            FROM students s
            LEFT JOIN attendance_logs al ON al.student_id = s.student_id
            WHERE s.is_active = 1
            GROUP BY s.student_id
            ORDER BY attended ASC
            LIMIT 5
        """) as cur:
            top_absentees = [dict(r) for r in await cur.fetchall()]

        async with db.execute("""
            SELECT date(al.marked_at) AS day, COUNT(DISTINCT al.student_id) AS count
            FROM attendance_logs al
            JOIN attendance_sessions s ON s.session_id = al.session_id
            WHERE s.is_deleted = 0
            GROUP BY day
            ORDER BY day DESC
            LIMIT 14
        """) as cur:
            daily_trend = [dict(r) for r in await cur.fetchall()]

        async with db.execute("""
            SELECT d.name AS dept, COUNT(DISTINCT al.student_id) AS present
            FROM attendance_logs al
            JOIN students st ON st.student_id = al.student_id
            JOIN departments d ON d.code = st.dept_code
            WHERE date(al.marked_at) = date('now')
            GROUP BY d.name
        """) as cur:
            dept_today = [dict(r) for r in await cur.fetchall()]

    attendance_rate = round(present_today / total_students * 100, 1) if total_students else 0

    return {
        "total_students":  total_students,
        "sessions_today":  sessions_today,
        "present_today":   present_today,
        "absent_today":    total_students - present_today,
        "attendance_rate": attendance_rate,
        "top_absentees":   top_absentees,
        "daily_trend":     list(reversed(daily_trend)),
        "dept_today":      dept_today,
    }


# ── Faculty dashboard endpoints ───────────────────────────────────────────────

@router.get("/faculty/all")
async def all_faculty():
    async with aiosqlite.connect(DB_PATH) as db:
        db.row_factory = aiosqlite.Row
        async with db.execute("""
            SELECT f.faculty_id, f.name, f.dept_code, f.email,
                   d.name AS dept_name,
                   COUNT(DISTINCT s.session_id) AS total_sessions
            FROM faculty f
            LEFT JOIN departments d ON d.code = f.dept_code
            LEFT JOIN attendance_sessions s
                   ON s.faculty_id = f.faculty_id AND s.is_deleted = 0
            WHERE f.is_active = 1
            GROUP BY f.faculty_id
            ORDER BY f.name
        """) as cur:
            rows = await cur.fetchall()
    return [dict(r) for r in rows]


@router.get("/faculty/{faculty_id}/sessions")
async def faculty_sessions(faculty_id: str):
    async with aiosqlite.connect(DB_PATH) as db:
        db.row_factory = aiosqlite.Row
        async with db.execute("""
            SELECT s.session_id, s.subject, s.dept_code,
                   d.name AS dept_name,
                   s.started_at, s.ended_at, s.is_active,
                   COUNT(al.id) AS attendance_count
            FROM attendance_sessions s
            LEFT JOIN departments d ON d.code = s.dept_code
            LEFT JOIN attendance_logs al ON al.session_id = s.session_id
            WHERE s.faculty_id = ? AND s.is_deleted = 0
            GROUP BY s.session_id
            ORDER BY s.started_at DESC
        """, (faculty_id,)) as cur:
            rows = await cur.fetchall()
    return [dict(r) for r in rows]
