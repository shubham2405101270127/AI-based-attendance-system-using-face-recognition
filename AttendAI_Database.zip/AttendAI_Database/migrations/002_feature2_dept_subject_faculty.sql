-- ============================================================
-- Migration 002 — Feature 2: Department / Subject / Faculty
-- ============================================================
-- Links attendance sessions to the new structured tables:
--   departments, subjects, faculty
-- Also creates those three tables if not already present.
-- ============================================================

-- New tables (created by database.py before migrations run)
-- departments: code TEXT PK, name TEXT
-- subjects:    name TEXT, dept_code FK
-- faculty:     faculty_id TEXT PK, name TEXT, dept_code FK

-- Add three new columns to attendance_sessions
ALTER TABLE attendance_sessions ADD COLUMN dept_code  TEXT;
ALTER TABLE attendance_sessions ADD COLUMN subject    TEXT;
ALTER TABLE attendance_sessions ADD COLUMN faculty_id TEXT;

-- After this migration, the Live Session page flow is:
--   1. Teacher picks Department  → loads subjects for that dept
--   2. Teacher picks Subject     → stored in sessions.subject
--   3. Teacher picks Faculty     → stored in sessions.faculty_id
--
-- Legacy sessions (created before this migration) will have
-- dept_code / subject / faculty_id = NULL which is fine.
-- They still show course / teacher (old string columns).

-- Indexes for the new FK columns
CREATE INDEX IF NOT EXISTS idx_sessions_dept    ON attendance_sessions(dept_code);
CREATE INDEX IF NOT EXISTS idx_sessions_faculty ON attendance_sessions(faculty_id);
