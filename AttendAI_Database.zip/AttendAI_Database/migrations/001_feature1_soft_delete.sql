-- ============================================================
-- Migration 001 — Feature 1: Smart Session Management
-- ============================================================
-- Adds soft-delete support to attendance_sessions.
-- Deleting a session from the dashboard sets is_deleted = 1.
-- The student's attendance_logs rows are NEVER touched.
-- ============================================================

-- Safe: SQLite will error if column already exists, which is caught
-- by database.py and silently ignored.

ALTER TABLE attendance_sessions ADD COLUMN is_deleted INTEGER DEFAULT 0;

-- After running this migration:
--   is_deleted = 0  → session visible in dashboard
--   is_deleted = 1  → session hidden from dashboard
--                      but ALL attendance_logs rows still exist
--                      and show up in student profile history

-- Dashboard queries now filter: WHERE is_deleted = 0
-- Student attendance queries ignore is_deleted entirely
