-- ============================================================
-- Migration 003 — Feature 3: Redesigned Student Registration
-- ============================================================
-- Adds new profile fields to the students table.
-- Roll number format changed to AUTO-GENERATED:
--   26 + dept_code (2 digits) + sequential number (2 digits)
--   Example: BTech (03) first student → 260301
-- ============================================================

-- New columns on students table
ALTER TABLE students ADD COLUMN city          TEXT DEFAULT '';
ALTER TABLE students ADD COLUMN dept_code     TEXT;
ALTER TABLE students ADD COLUMN phone         TEXT DEFAULT '';
ALTER TABLE students ADD COLUMN guardian_type TEXT DEFAULT 'Father';
ALTER TABLE students ADD COLUMN guardian_rel  TEXT DEFAULT '';

-- guardian_type values: 'Mother' | 'Father' | 'Guardian'
-- guardian_rel: filled only when guardian_type = 'Guardian'
--   e.g. 'Uncle', 'Elder Sibling', 'Aunt'

-- dept_code FK links student to departments table
-- Used for:
--   1. Generating the roll number (26 + dept_code + seq)
--   2. Filtering students by department in reports
--   3. Showing dept name in student profile

-- Index for department-based queries
CREATE INDEX IF NOT EXISTS idx_students_dept ON students(dept_code);

-- Roll number generation logic (in Python, not SQL):
--   count = SELECT COUNT(*) FROM students WHERE dept_code = ? AND is_active = 1
--   student_id = f"26{dept_code}{count+1:02d}"
