"""
AttendAI — export_attendance.py
================================
Standalone script to export attendance data from the SQLite database
to CSV and Excel files without needing the server to be running.

Usage:
    python exports/export_attendance.py                    # export today
    python exports/export_attendance.py --session ABC123   # one session
    python exports/export_attendance.py --all              # all sessions
    python exports/export_attendance.py --date 2026-06-01  # specific date

Output files are saved to  exports/output/
"""

import asyncio
import aiosqlite
import csv
import os
import sys
import argparse
from datetime import date, datetime

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from database import DB_PATH

OUTPUT_DIR = os.path.join(os.path.dirname(__file__), "output")


async def export_session(session_id: str):
    """Export one session's attendance to CSV."""
    os.makedirs(OUTPUT_DIR, exist_ok=True)
    async with aiosqlite.connect(DB_PATH) as db:
        db.row_factory = aiosqlite.Row
        async with db.execute("""
            SELECT
                al.student_id,
                s.name,
                s.dept_code,
                d.name   AS dept_name,
                al.confidence,
                al.marked_at,
                al.status,
                sess.subject,
                f.name   AS faculty_name,
                sess.started_at
            FROM attendance_logs al
            JOIN students s         ON s.student_id  = al.student_id
            JOIN attendance_sessions sess ON sess.session_id = al.session_id
            LEFT JOIN departments d ON d.code        = s.dept_code
            LEFT JOIN faculty f     ON f.faculty_id  = sess.faculty_id
            WHERE al.session_id = ?
            ORDER BY al.marked_at
        """, (session_id,)) as cur:
            rows = [dict(r) for r in await cur.fetchall()]

    if not rows:
        print(f"No records found for session {session_id}")
        return

    filename = os.path.join(OUTPUT_DIR, f"attendance_{session_id}.csv")
    with open(filename, "w", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=[
            "student_id", "name", "dept_name", "subject",
            "faculty_name", "confidence", "marked_at", "status"
        ])
        writer.writeheader()
        for row in rows:
            writer.writerow({
                "student_id":   row["student_id"],
                "name":         row["name"],
                "dept_name":    row["dept_name"] or "—",
                "subject":      row["subject"] or "—",
                "faculty_name": row["faculty_name"] or "—",
                "confidence":   f"{round((row['confidence'] or 0)*100, 1)}%",
                "marked_at":    row["marked_at"],
                "status":       row["status"],
            })
    print(f"Exported {len(rows)} records → {filename}")


async def export_date(target_date: str):
    """Export all attendance for a given date (YYYY-MM-DD)."""
    os.makedirs(OUTPUT_DIR, exist_ok=True)
    async with aiosqlite.connect(DB_PATH) as db:
        db.row_factory = aiosqlite.Row
        async with db.execute("""
            SELECT
                al.session_id,
                al.student_id,
                s.name,
                d.name   AS dept_name,
                al.confidence,
                al.marked_at,
                sess.subject,
                f.name   AS faculty_name
            FROM attendance_logs al
            JOIN students s           ON s.student_id   = al.student_id
            JOIN attendance_sessions sess ON sess.session_id = al.session_id
            LEFT JOIN departments d   ON d.code         = s.dept_code
            LEFT JOIN faculty f       ON f.faculty_id   = sess.faculty_id
            WHERE date(al.marked_at) = ?
              AND sess.is_deleted = 0
            ORDER BY al.marked_at
        """, (target_date,)) as cur:
            rows = [dict(r) for r in await cur.fetchall()]

    if not rows:
        print(f"No attendance records found for {target_date}")
        return

    filename = os.path.join(OUTPUT_DIR, f"attendance_date_{target_date}.csv")
    with open(filename, "w", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=[
            "session_id", "student_id", "name", "dept_name",
            "subject", "faculty_name", "confidence", "marked_at"
        ])
        writer.writeheader()
        for row in rows:
            writer.writerow({
                "session_id":   row["session_id"],
                "student_id":   row["student_id"],
                "name":         row["name"],
                "dept_name":    row["dept_name"] or "—",
                "subject":      row["subject"] or "—",
                "faculty_name": row["faculty_name"] or "—",
                "confidence":   f"{round((row['confidence'] or 0)*100, 1)}%",
                "marked_at":    row["marked_at"],
            })
    print(f"Exported {len(rows)} records for {target_date} → {filename}")


async def export_all():
    """Export every non-deleted session to separate CSV files."""
    async with aiosqlite.connect(DB_PATH) as db:
        db.row_factory = aiosqlite.Row
        async with db.execute(
            "SELECT session_id FROM attendance_sessions WHERE is_deleted=0"
        ) as cur:
            sessions = [r["session_id"] for r in await cur.fetchall()]
    for sid in sessions:
        await export_session(sid)
    print(f"\nDone — exported {len(sessions)} sessions to {OUTPUT_DIR}/")


def main():
    parser = argparse.ArgumentParser(description="AttendAI — Export attendance to CSV")
    parser.add_argument("--session", help="Export one session by ID")
    parser.add_argument("--date",    help="Export all attendance for a date (YYYY-MM-DD)")
    parser.add_argument("--all",     action="store_true", help="Export all sessions")
    args = parser.parse_args()

    if args.session:
        asyncio.run(export_session(args.session))
    elif args.date:
        asyncio.run(export_date(args.date))
    elif args.all:
        asyncio.run(export_all())
    else:
        # Default: export today
        today = date.today().isoformat()
        print(f"Exporting today ({today})...")
        asyncio.run(export_date(today))

if __name__ == "__main__":
    main()
