# AttendAI — ER Diagram (Text)

## Tables and Relationships

```
departments (code PK)
    |
    |── subjects (dept_code FK)          1 dept → many subjects
    |
    |── faculty (dept_code FK)           1 dept → many faculty
    |
    |── students (dept_code FK)          1 dept → many students
    |
    └── attendance_sessions (dept_code FK)

students (student_id PK)
    |
    |── face_embeddings (student_id FK)  1 student → many face photos
    |
    └── attendance_logs (student_id FK)  1 student → many attendance records

attendance_sessions (session_id PK)
    |
    └── attendance_logs (session_id FK)  1 session → many attendance records
         UNIQUE(session_id, student_id) — prevents double-marking

faculty (faculty_id PK)
    |
    └── attendance_sessions (faculty_id FK)  1 faculty → many sessions
```

## All 7 Tables

### departments
| Column     | Type    | Notes                        |
|------------|---------|------------------------------|
| id         | INTEGER | PK, autoincrement            |
| code       | TEXT    | UNIQUE — '01' '03' '05' ... |
| name       | TEXT    | UNIQUE — 'BCA' 'BTech' ...  |
| created_at | TEXT    | datetime default             |

### subjects
| Column     | Type    | Notes                        |
|------------|---------|------------------------------|
| id         | INTEGER | PK                           |
| name       | TEXT    | subject title                |
| dept_code  | TEXT    | FK → departments.code        |
| created_at | TEXT    |                              |
| UNIQUE(name, dept_code)                              |

### faculty
| Column     | Type    | Notes                        |
|------------|---------|------------------------------|
| faculty_id | TEXT    | PK — 'FAC001' 'FAC002' ...  |
| name       | TEXT    |                              |
| dept_code  | TEXT    | FK → departments.code        |
| email      | TEXT    |                              |
| is_active  | INTEGER | 1=active, 0=deactivated      |

### students
| Column        | Type    | Notes                              |
|---------------|---------|------------------------------------|
| student_id    | TEXT    | PK — roll number e.g. '260301'    |
| name          | TEXT    |                                    |
| city          | TEXT    | Feature 3                          |
| dept_code     | TEXT    | FK → departments.code (Feature 3)  |
| phone         | TEXT    | Feature 3                          |
| guardian_type | TEXT    | Mother / Father / Guardian         |
| guardian_rel  | TEXT    | filled if guardian_type=Guardian   |
| photo_count   | INTEGER | incremented on each face capture   |
| enrolled_at   | TEXT    |                                    |
| is_active     | INTEGER | 0 = soft deleted                   |

### face_embeddings
| Column     | Type    | Notes                              |
|------------|---------|------------------------------------|
| id         | INTEGER | PK                                 |
| student_id | TEXT    | FK → students.student_id           |
| embedding  | BLOB    | pickled numpy array (128 floats)   |
| captured_at| TEXT    |                                    |

### attendance_sessions
| Column     | Type    | Notes                              |
|------------|---------|------------------------------------|
| session_id | TEXT    | PK — 8-char UUID e.g. 'A1B2C3D4' |
| dept_code  | TEXT    | FK → departments.code (Feature 2)  |
| subject    | TEXT    | Feature 2                          |
| faculty_id | TEXT    | FK → faculty.faculty_id (F2)       |
| started_at | TEXT    |                                    |
| ended_at   | TEXT    | NULL while session is live         |
| is_active  | INTEGER | 1 while live                       |
| is_deleted | INTEGER | 1 = hidden from dashboard (F1)     |

### attendance_logs
| Column     | Type    | Notes                              |
|------------|---------|------------------------------------|
| id         | INTEGER | PK                                 |
| session_id | TEXT    | FK → attendance_sessions           |
| student_id | TEXT    | FK → students                      |
| status     | TEXT    | 'present' (default)                |
| confidence | REAL    | cosine similarity (0.0 – 1.0)      |
| marked_at  | TEXT    |                                    |
| UNIQUE(session_id, student_id) — no double-marking   |

## Key Design Decisions

1. **Soft delete everywhere** — sessions are never hard-deleted.
   `is_deleted=1` hides them from the dashboard but all `attendance_logs`
   rows are fully preserved. Student profiles always show full history.

2. **Roll number format** — `26` + 2-digit dept code + 2-digit sequence.
   First BTech student (code 03): `260301`. Second: `260302`.
   Mirrors how real college IDs work.

3. **Face embeddings as BLOBs** — each captured photo produces one
   128-float numpy array stored via Python `pickle`. Multiple embeddings
   per student improve recognition accuracy across angles.

4. **UNIQUE constraint on attendance_logs** — the database itself
   prevents a student from being marked present twice in the same session,
   regardless of how many times their face is detected.

5. **WAL mode** — enables concurrent reads while a write is in progress,
   so the camera stream and the dashboard can both access the DB simultaneously.
