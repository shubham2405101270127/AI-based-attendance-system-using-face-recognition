"""
AttendAI — Database Reset Script
==================================
File:    scripts/reset_db.py
WARNING: This deletes ALL data permanently.
         Use only during development / testing.

Usage:
    python scripts/reset_db.py

What it does:
    1. Deletes data/attendance.db
    2. Re-creates all tables (via init_db)
    3. Re-seeds departments, subjects and faculty
"""

import asyncio
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

DB_PATH = "data/attendance.db"


async def reset():
    confirm = input(
        "\n⚠  WARNING: This will DELETE all students, sessions and attendance records.\n"
        "   Type YES to confirm: "
    ).strip()

    if confirm != "YES":
        print("Cancelled.")
        return

    if os.path.exists(DB_PATH):
        os.remove(DB_PATH)
        print(f"Deleted: {DB_PATH}")

    # Re-run seed
    from scripts.seed_master import seed
    await seed()
    print("\n✓ Database reset complete.")


asyncio.run(reset())
