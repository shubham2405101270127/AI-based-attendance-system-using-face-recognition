"""
AttendAI — Database Inspector Script
======================================
File:    scripts/inspect_db.py
Role:    Prints a quick summary of everything in the database.
         Useful for debugging and verifying data after seeding.

Usage:
    python scripts/inspect_db.py
"""

import asyncio
import sys
import os

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

import aiosqlite
DB_PATH = "data/attendance.db"


async def inspect():
    if not os.path.exists(DB_PATH):
        print(f"Database not found at {DB_PATH}")
        print("Run the server once first, then run seed_master.py")
        return

    async with aiosqlite.connect(DB_PATH) as db:
        db.row_factory = aiosqlite.Row

        tables = ["departments", "subjects", "faculty",
                  "students", "face_embeddings",
                  "attendance_sessions", "attendance_logs"]

        print(f"\n{'='*50}")
        print(f"  AttendAI Database: {DB_PATH}")
        print(f"{'='*50}\n")

        for table in tables:
            async with db.execute(f"SELECT COUNT(*) FROM {table}") as cur:
                count = (await cur.fetchone())[0]
            print(f"  {table:<30} {count:>5} rows")

        print()

        # Show all departments
        print("Departments:")
        async with db.execute("SELECT code, name FROM departments ORDER BY code") as cur:
            for row in await cur.fetchall():
                print(f"  [{row['code']}] {row['name']}")

        # Show latest 5 students
        print("\nLatest students (up to 5):")
        async with db.execute(
            "SELECT student_id, name, dept_code, photo_count FROM students "
            "WHERE is_active=1 ORDER BY enrolled_at DESC LIMIT 5"
        ) as cur:
            rows = await cur.fetchall()
            if rows:
                for r in rows:
                    print(f"  {r['student_id']}  {r['name']:<25}  "
                          f"dept:{r['dept_code']}  photos:{r['photo_count']}")
            else:
                print("  No students enrolled yet.")

        # Show latest 5 sessions
        print("\nLatest sessions (up to 5):")
        async with db.execute(
            "SELECT session_id, subject, started_at, is_active FROM attendance_sessions "
            "WHERE is_deleted=0 ORDER BY started_at DESC LIMIT 5"
        ) as cur:
            rows = await cur.fetchall()
            if rows:
                for r in rows:
                    status = "LIVE" if r['is_active'] else "Ended"
                    print(f"  {r['session_id']}  {str(r['subject'] or '—'):<30}  "
                          f"{r['started_at'][:16]}  [{status}]")
            else:
                print("  No sessions yet.")

        print(f"\n{'='*50}\n")


asyncio.run(inspect())
