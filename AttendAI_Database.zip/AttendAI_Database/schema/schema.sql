-- ============================================================
-- AttendAI — Full Database Schema
-- File: schema/schema.sql
-- For reference/documentation only.
-- Actual DB is created by database.py at runtime.
-- ============================================================

PRAGMA journal_mode = WAL;

-- 1. students
CREATE TABLE IF NOT EXISTS students (
    id            INTEGER PRIMARY KEY AUTOINCREMENT,
    student_id    TEXT    UNIQUE NOT NULL,   -- auto: 26+dept_code+seq e.g. 260301
    name          TEXT    NOT NULL,
    city          TEXT    DEFAULT '',
    phone         TEXT    DEFAULT '',
    guardian_type TEXT    DEFAULT 'Father',  -- Mother | Father | Guardian
    guardian_rel  TEXT    DEFAULT '',
    dept_code     TEXT    REFERENCES departments(code),
    email         TEXT    DEFAULT '',
    course        TEXT    DEFAULT '',
    photo_count   INTEGER DEFAULT 0,
    enrolled_at   TEXT    DEFAULT (datetime('now')),
    is_active     INTEGER DEFAULT 1
);

-- 2. face_embeddings
CREATE TABLE IF NOT EXISTS face_embeddings (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    student_id  TEXT    NOT NULL REFERENCES students(student_id),
    embedding   BLOB    NOT NULL,   -- pickle.dumps(numpy array 128-d)
    captured_at TEXT    DEFAULT (datetime('now'))
);

-- 3. departments
CREATE TABLE IF NOT EXISTS departments (
    id         INTEGER PRIMARY KEY AUTOINCREMENT,
    code       TEXT    UNIQUE NOT NULL,  -- '01','03','05','07','09'
    name       TEXT    UNIQUE NOT NULL,  -- 'BCA','BTech','BDes','BPharm','MBA'
    created_at TEXT    DEFAULT (datetime('now'))
);

-- 4. subjects
CREATE TABLE IF NOT EXISTS subjects (
    id         INTEGER PRIMARY KEY AUTOINCREMENT,
    name       TEXT    NOT NULL,
    dept_code  TEXT    NOT NULL REFERENCES departments(code),
    created_at TEXT    DEFAULT (datetime('now')),
    UNIQUE(name, dept_code)
);

-- 5. faculty
CREATE TABLE IF NOT EXISTS faculty (
    id         INTEGER PRIMARY KEY AUTOINCREMENT,
    faculty_id TEXT    UNIQUE NOT NULL,  -- FAC001 … FAC025
    name       TEXT    NOT NULL,
    dept_code  TEXT    NOT NULL REFERENCES departments(code),
    email      TEXT    DEFAULT '',
    created_at TEXT    DEFAULT (datetime('now')),
    is_active  INTEGER DEFAULT 1
);

-- 6. attendance_sessions
CREATE TABLE IF NOT EXISTS attendance_sessions (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    session_id  TEXT    UNIQUE NOT NULL,  -- 8-char UUID e.g. 'A3F9B21C'
    course      TEXT,
    teacher     TEXT,
    dept_code   TEXT    REFERENCES departments(code),
    subject     TEXT,
    faculty_id  TEXT    REFERENCES faculty(faculty_id),
    started_at  TEXT    DEFAULT (datetime('now')),
    ended_at    TEXT,
    is_active   INTEGER DEFAULT 1,
    is_deleted  INTEGER DEFAULT 0   -- soft-delete; logs always preserved
);

-- 7. attendance_logs
CREATE TABLE IF NOT EXISTS attendance_logs (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    session_id  TEXT    NOT NULL REFERENCES attendance_sessions(session_id),
    student_id  TEXT    NOT NULL REFERENCES students(student_id),
    status      TEXT    DEFAULT 'present',
    confidence  REAL,
    marked_at   TEXT    DEFAULT (datetime('now')),
    UNIQUE(session_id, student_id)
);

-- Indexes
CREATE INDEX IF NOT EXISTS idx_logs_session   ON attendance_logs(session_id);
CREATE INDEX IF NOT EXISTS idx_logs_student   ON attendance_logs(student_id);
CREATE INDEX IF NOT EXISTS idx_embed_student  ON face_embeddings(student_id);
CREATE INDEX IF NOT EXISTS idx_subjects_dept  ON subjects(dept_code);
CREATE INDEX IF NOT EXISTS idx_faculty_dept   ON faculty(dept_code);
CREATE INDEX IF NOT EXISTS idx_students_dept  ON students(dept_code);

-- ============================================================
-- Relationships
-- ============================================================
-- students         → face_embeddings    1:many
-- students         → attendance_logs    1:many
-- departments      → students           1:many
-- departments      → subjects           1:many
-- departments      → faculty            1:many
-- attendance_sessions → attendance_logs 1:many
-- faculty          → attendance_sessions 1:many
