"""
AttendAI — database.py  (MAIN FILE)
=====================================
This is the main database file for the AttendAI project.

Responsibilities:
- Creates all 7 tables on first run
- Runs safe ALTER TABLE migrations for Features 1, 2, and 3
  (safe = won't crash if column already exists)
- Creates indexes after all migrations complete
- Exposes DB_PATH and get_db() used by every API module

Tables created:
  1. students           — enrolled students with guardian + dept info
  2. face_embeddings    — 128-d face vectors stored as binary blobs
  3. departments        — 5 dept codes (BCA=01, BTech=03, BDes=05, BPharm=07, MBA=09)
  4. subjects           — 5 subjects per dept (25 total)
  5. faculty            — 5 faculty per dept (25 total)
  6. attendance_sessions— one row per live session taken by a faculty member
  7. attendance_logs    — one row per student marked present in a session

Run order on startup:
  Step 1 → CREATE TABLE IF NOT EXISTS  (all 7 tables)
  Step 2 → ALTER TABLE migrations       (add new columns safely)
  Step 3 → CREATE INDEX IF NOT EXISTS   (after columns exist)
"""

import aiosqlite
import os

DB_PATH = "data/attendance.db"


async def init_db():
    """
    Called once at application startup via FastAPI lifespan event in main.py.
    Creates the data/ folder if missing, then runs all three steps.
    """
    os.makedirs("data", exist_ok=True)

    async with aiosqlite.connect(DB_PATH) as db:

        # ── STEP 1: Create all tables ─────────────────────────────────────────
        await db.execute("PRAGMA journal_mode=WAL")

        await db.execute("""
            CREATE TABLE IF NOT EXISTS students (
                id            INTEGER PRIMARY KEY AUTOINCREMENT,
                student_id    TEXT    UNIQUE NOT NULL,
                name          TEXT    NOT NULL,
                email         TEXT    DEFAULT '',
                course        TEXT    DEFAULT '',
                photo_count   INTEGER DEFAULT 0,
                enrolled_at   TEXT    DEFAULT (datetime('now')),
                is_active     INTEGER DEFAULT 1
            )
        """)

        await db.execute("""
            CREATE TABLE IF NOT EXISTS face_embeddings (
                id          INTEGER PRIMARY KEY AUTOINCREMENT,
                student_id  TEXT    NOT NULL REFERENCES students(student_id),
                embedding   BLOB    NOT NULL,
                captured_at TEXT    DEFAULT (datetime('now'))
            )
        """)

        await db.execute("""
            CREATE TABLE IF NOT EXISTS departments (
                id         INTEGER PRIMARY KEY AUTOINCREMENT,
                code       TEXT    UNIQUE NOT NULL,
                name       TEXT    UNIQUE NOT NULL,
                created_at TEXT    DEFAULT (datetime('now'))
            )
        """)

        await db.execute("""
            CREATE TABLE IF NOT EXISTS subjects (
                id         INTEGER PRIMARY KEY AUTOINCREMENT,
                name       TEXT    NOT NULL,
                dept_code  TEXT    NOT NULL REFERENCES departments(code),
                created_at TEXT    DEFAULT (datetime('now')),
                UNIQUE(name, dept_code)
            )
        """)

        await db.execute("""
            CREATE TABLE IF NOT EXISTS faculty (
                id         INTEGER PRIMARY KEY AUTOINCREMENT,
                faculty_id TEXT    UNIQUE NOT NULL,
                name       TEXT    NOT NULL,
                dept_code  TEXT    NOT NULL REFERENCES departments(code),
                email      TEXT    DEFAULT '',
                created_at TEXT    DEFAULT (datetime('now')),
                is_active  INTEGER DEFAULT 1
            )
        """)

        await db.execute("""
            CREATE TABLE IF NOT EXISTS attendance_sessions (
                id          INTEGER PRIMARY KEY AUTOINCREMENT,
                session_id  TEXT    UNIQUE NOT NULL,
                course      TEXT,
                teacher     TEXT,
                started_at  TEXT    DEFAULT (datetime('now')),
                ended_at    TEXT,
                is_active   INTEGER DEFAULT 1
            )
        """)

        await db.execute("""
            CREATE TABLE IF NOT EXISTS attendance_logs (
                id          INTEGER PRIMARY KEY AUTOINCREMENT,
                session_id  TEXT    NOT NULL REFERENCES attendance_sessions(session_id),
                student_id  TEXT    NOT NULL REFERENCES students(student_id),
                status      TEXT    DEFAULT 'present',
                confidence  REAL,
                marked_at   TEXT    DEFAULT (datetime('now')),
                UNIQUE(session_id, student_id)
            )
        """)

        await db.commit()

        # ── STEP 2: Safe migrations ───────────────────────────────────────────
        # Each ALTER TABLE is wrapped in try/except.
        # If the column already exists SQLite raises OperationalError → we skip it.
        # This means the app can restart any number of times without errors.

        migrations = [
            # Feature 1 — soft-delete sessions without losing attendance logs
            "ALTER TABLE attendance_sessions ADD COLUMN is_deleted  INTEGER DEFAULT 0",

            # Feature 2 — link sessions to dept / subject / faculty
            "ALTER TABLE attendance_sessions ADD COLUMN dept_code   TEXT",
            "ALTER TABLE attendance_sessions ADD COLUMN subject     TEXT",
            "ALTER TABLE attendance_sessions ADD COLUMN faculty_id  TEXT",

            # Feature 3 — new student registration fields
            "ALTER TABLE students ADD COLUMN city          TEXT DEFAULT ''",
            "ALTER TABLE students ADD COLUMN dept_code     TEXT",
            "ALTER TABLE students ADD COLUMN phone         TEXT DEFAULT ''",
            "ALTER TABLE students ADD COLUMN guardian_type TEXT DEFAULT 'Father'",
            "ALTER TABLE students ADD COLUMN guardian_rel  TEXT DEFAULT ''",
        ]

        for sql in migrations:
            try:
                await db.execute(sql)
                await db.commit()
            except Exception:
                pass   # column already exists — safe to ignore

        # ── STEP 3: Indexes (created AFTER migrations so columns exist) ───────
        # Each index is also wrapped so re-runs are safe.

        indexes = [
            "CREATE INDEX IF NOT EXISTS idx_logs_session   ON attendance_logs(session_id)",
            "CREATE INDEX IF NOT EXISTS idx_logs_student   ON attendance_logs(student_id)",
            "CREATE INDEX IF NOT EXISTS idx_embed_student  ON face_embeddings(student_id)",
            "CREATE INDEX IF NOT EXISTS idx_subjects_dept  ON subjects(dept_code)",
            "CREATE INDEX IF NOT EXISTS idx_faculty_dept   ON faculty(dept_code)",
            "CREATE INDEX IF NOT EXISTS idx_students_dept  ON students(dept_code)",
        ]

        for sql in indexes:
            try:
                await db.execute(sql)
                await db.commit()
            except Exception:
                pass   # index already exists — safe to ignore

        await db.commit()

    print(f"[DB] Initialized successfully → {DB_PATH}")


async def get_db():
    """
    Async context manager — yields a connected aiosqlite database with
    row_factory set so rows behave like dicts.

    Usage in any API endpoint:
        async with aiosqlite.connect(DB_PATH) as db:
            db.row_factory = aiosqlite.Row
            ...
    """
    async with aiosqlite.connect(DB_PATH) as db:
        db.row_factory = aiosqlite.Row
        yield db
