# AttendAI — Database Module

This folder contains everything related to the SQLite database used by the
AI-Based Attendance System.

---

## Folder Structure

```
AttendAI_Database/
│
├── database.py          ← MAIN FILE — run this to initialise the database
├── main_database.py     ← Entry point alias (same as database.py, use either)
│
├── schema/
│   └── schema.sql       ← Full schema documentation (reference only)
│
├── migrations/
│   ├── 001_feature1_soft_delete.sql          ← Adds is_deleted to sessions
│   ├── 002_feature2_dept_subject_faculty.sql ← Links sessions to dept/subj/faculty
│   └── 003_feature3_student_profile.sql      ← Adds city/phone/guardian to students
│
├── seeds/
│   └── seed_master.py   ← Populates 5 depts · 25 subjects · 25 faculty
│
├── scripts/
│   ├── inspect_db.py    ← Browse tables and row counts from terminal
│   └── reset_db.py      ← Delete the database and start fresh (with confirmation)
│
├── exports/
│   ├── export_attendance.py ← Export attendance to CSV from terminal
│   └── output/              ← CSV files saved here (auto-created)
│
└── docs/
    └── ER_Diagram.md    ← Entity-Relationship diagram in text format
```

---

## How to Use

### 1. Database initialises automatically
When you run `uvicorn main:app --reload` from the project root, the
`init_db()` function in `database.py` is called automatically via
FastAPI's lifespan event. You do not need to run anything manually.

The database file is created at: `data/attendance.db`

### 2. Seed master data (run once)
After the first startup:
```bash
python seeds/seed_master.py
```
This adds 5 departments, 25 subjects and 25 faculty members.

### 3. Inspect the database
```bash
python scripts/inspect_db.py
```

### 4. Export attendance to CSV
```bash
python exports/export_attendance.py                    # today's attendance
python exports/export_attendance.py --session ABC123   # one session
python exports/export_attendance.py --date 2026-06-01  # specific date
python exports/export_attendance.py --all              # all sessions
```

### 5. Reset the database (WARNING: deletes all data)
```bash
python scripts/reset_db.py
```

---

## Tables

| Table | Purpose |
|---|---|
| `students` | All enrolled students with auto roll numbers |
| `face_embeddings` | 128-d face vectors (pickled numpy arrays) |
| `departments` | 5 departments with 2-digit codes |
| `subjects` | 5 subjects per department (25 total) |
| `faculty` | 5 faculty per department (25 total) |
| `attendance_sessions` | One row per live class session |
| `attendance_logs` | One row per student marked present |

---

## Roll Number Format

```
26  +  dept_code  +  sequence
──      ────────     ────────
Year    2 digits     2 digits (sequential within dept)

Examples:
  BCA  (01) → 260101, 260102, 260103 …
  BTech(03) → 260301, 260302, 260303 …
  BDes (05) → 260501, 260502, 260503 …
```

---

## Key Design Decisions

- **Soft-delete on sessions** — `is_deleted = 1` hides a session from the
  dashboard but never removes `attendance_logs`. Student profiles always
  show complete history.

- **Migrations are idempotent** — Every `ALTER TABLE` is wrapped in
  `try/except`. The app can restart any number of times without errors.

- **Indexes after migrations** — All `CREATE INDEX` statements run after
  all `ALTER TABLE` statements so new columns always exist when indexed.

- **aiosqlite with WAL mode** — Allows simultaneous reads (dashboard polling)
  and writes (marking attendance) without blocking the camera stream.
