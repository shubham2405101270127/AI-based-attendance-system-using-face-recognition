"""
AttendAI Database — Main Entry File
======================================
File:    main_database.py
Role:    MAIN FILE for the Database layer.
         Contains the complete database initialisation function (init_db),
         the DB_PATH constant, and a get_db() helper.
         Import this in the backend with:
             from app.models.database import init_db, DB_PATH

Database engine:  SQLite (file: data/attendance.db)
Async driver:     aiosqlite
Mode:             WAL (Write-Ahead Logging) for concurrent reads

Tables (7 total):
  1. students           — enrolled students with roll numbers, guardian info
  2. face_embeddings    — 128-d face vectors stored as binary blobs
  3. departments        — 5 departments (BCA, BTech, BDes, BPharm, MBA)
  4. subjects           — 25 subjects (5 per department)
  5. faculty            — 25 faculty members (5 per department)
  6. attendance_sessions — each class session with dept/subject/faculty link
  7. attendance_logs    — individual attendance records per student per session

Migration strategy:
  Each ALTER TABLE is wrapped in try/except.
  Safe to restart the server at any time — existing data is never lost.
"""

import aiosqlite
import os

# Path to the SQLite database file (auto-created on first run)
DB_PATH = "data/attendance.db"


async def init_db():
    """
    Initialise the database.
    Called once on server startup via FastAPI lifespan event.
    Steps:
      1. Create tables (if they don't already exist)
      2. Run column migrations (safe, idempotent)
      3. Create indexes (after migrations so columns exist)
    """
    os.makedirs("data", exist_ok=True)

    async with aiosqlite.connect(DB_PATH) as db:

        # ── WAL mode for better concurrent performance ──────────────────────
        await db.execute("PRAGMA journal_mode=WAL")

        # ══════════════════════════════════════════════════════════════════════
        # STEP 1 — Create all tables
        # Each uses IF NOT EXISTS so this is safe to re-run at any time.
        # ══════════════════════════════════════════════════════════════════════

        await db.execute("""
            CREATE TABLE IF NOT EXISTS students (
                id            INTEGER PRIMARY KEY AUTOINCREMENT,
                student_id    TEXT    UNIQUE NOT NULL,
                name          TEXT    NOT NULL,
                email         TEXT    DEFAULT '',
                course        TEXT    DEFAULT '',
                photo_count   INTEGER DEFAULT 0,
                enrolled_at   TEXT    DEFAULT (datetime('now')),
                is_active     INTEGER DEFAULT 1
            )
        """)

        await db.execute("""
            CREATE TABLE IF NOT EXISTS face_embeddings (
                id          INTEGER PRIMARY KEY AUTOINCREMENT,
                student_id  TEXT    NOT NULL REFERENCES students(student_id),
                embedding   BLOB    NOT NULL,
                captured_at TEXT    DEFAULT (datetime('now'))
            )
        """)

        await db.execute("""
            CREATE TABLE IF NOT EXISTS departments (
                id         INTEGER PRIMARY KEY AUTOINCREMENT,
                code       TEXT    UNIQUE NOT NULL,
                name       TEXT    UNIQUE NOT NULL,
                created_at TEXT    DEFAULT (datetime('now'))
            )
        """)

        await db.execute("""
            CREATE TABLE IF NOT EXISTS subjects (
                id         INTEGER PRIMARY KEY AUTOINCREMENT,
                name       TEXT    NOT NULL,
                dept_code  TEXT    NOT NULL REFERENCES departments(code),
                created_at TEXT    DEFAULT (datetime('now')),
                UNIQUE(name, dept_code)
            )
        """)

        await db.execute("""
            CREATE TABLE IF NOT EXISTS faculty (
                id         INTEGER PRIMARY KEY AUTOINCREMENT,
                faculty_id TEXT    UNIQUE NOT NULL,
                name       TEXT    NOT NULL,
                dept_code  TEXT    NOT NULL REFERENCES departments(code),
                email      TEXT    DEFAULT '',
                created_at TEXT    DEFAULT (datetime('now')),
                is_active  INTEGER DEFAULT 1
            )
        """)

        await db.execute("""
            CREATE TABLE IF NOT EXISTS attendance_sessions (
                id          INTEGER PRIMARY KEY AUTOINCREMENT,
                session_id  TEXT    UNIQUE NOT NULL,
                course      TEXT,
                teacher     TEXT,
                started_at  TEXT    DEFAULT (datetime('now')),
                ended_at    TEXT,
                is_active   INTEGER DEFAULT 1
            )
        """)

        await db.execute("""
            CREATE TABLE IF NOT EXISTS attendance_logs (
                id          INTEGER PRIMARY KEY AUTOINCREMENT,
                session_id  TEXT    NOT NULL REFERENCES attendance_sessions(session_id),
                student_id  TEXT    NOT NULL REFERENCES students(student_id),
                status      TEXT    DEFAULT 'present',
                confidence  REAL,
                marked_at   TEXT    DEFAULT (datetime('now')),
                UNIQUE(session_id, student_id)
            )
        """)

        await db.commit()

        # ══════════════════════════════════════════════════════════════════════
        # STEP 2 — Safe column migrations
        # These add new columns to existing databases from older versions.
        # Each is wrapped in try/except — if the column already exists,
        # SQLite raises an error which we silently ignore.
        # ══════════════════════════════════════════════════════════════════════

        migrations = [
            # Feature 1: soft-delete sessions
            "ALTER TABLE attendance_sessions ADD COLUMN is_deleted  INTEGER DEFAULT 0",

            # Feature 2: link sessions to dept/subject/faculty
            "ALTER TABLE attendance_sessions ADD COLUMN dept_code   TEXT",
            "ALTER TABLE attendance_sessions ADD COLUMN subject     TEXT",
            "ALTER TABLE attendance_sessions ADD COLUMN faculty_id  TEXT",

            # Feature 3: extended student profile
            "ALTER TABLE students ADD COLUMN city          TEXT DEFAULT ''",
            "ALTER TABLE students ADD COLUMN dept_code     TEXT",
            "ALTER TABLE students ADD COLUMN phone         TEXT DEFAULT ''",
            "ALTER TABLE students ADD COLUMN guardian_type TEXT DEFAULT 'Father'",
            "ALTER TABLE students ADD COLUMN guardian_rel  TEXT DEFAULT ''",
        ]

        for sql in migrations:
            try:
                await db.execute(sql)
                await db.commit()
            except Exception:
                pass  # column already exists — safe to ignore

        # ══════════════════════════════════════════════════════════════════════
        # STEP 3 — Create indexes
        # Done AFTER migrations so all columns exist before being indexed.
        # ══════════════════════════════════════════════════════════════════════

        indexes = [
            "CREATE INDEX IF NOT EXISTS idx_logs_session   ON attendance_logs(session_id)",
            "CREATE INDEX IF NOT EXISTS idx_logs_student   ON attendance_logs(student_id)",
            "CREATE INDEX IF NOT EXISTS idx_embed_student  ON face_embeddings(student_id)",
            "CREATE INDEX IF NOT EXISTS idx_subjects_dept  ON subjects(dept_code)",
            "CREATE INDEX IF NOT EXISTS idx_faculty_dept   ON faculty(dept_code)",
            "CREATE INDEX IF NOT EXISTS idx_students_dept  ON students(dept_code)",
        ]

        for sql in indexes:
            try:
                await db.execute(sql)
                await db.commit()
            except Exception:
                pass  # index already exists

        await db.commit()

    print(f"[DB] Initialised at {DB_PATH}")


async def get_db():
    """
    Async context manager for one-off DB connections.
    Usage:
        async with aiosqlite.connect(DB_PATH) as db:
            db.row_factory = aiosqlite.Row
            ...
    """
    async with aiosqlite.connect(DB_PATH) as db:
        db.row_factory = aiosqlite.Row
        yield db
